export default [
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\docusaurus-hostybee\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\docusaurus-hostybee\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\docusaurus-hostybee\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\docusaurus-hostybee\\src\\css\\custom.css"),
];
