import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', '5ff'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', '5ba'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', 'a2b'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', 'c3c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', '156'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '88c'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '000'),
    exact: true
  },
  {
    path: '/my-markdown-page',
    component: ComponentCreator('/my-markdown-page', '438'),
    exact: true
  },
  {
    path: '/',
    component: ComponentCreator('/', '39c'),
    routes: [
      {
        path: '/',
        component: ComponentCreator('/', 'c55'),
        routes: [
          {
            path: '/',
            component: ComponentCreator('/', '62a'),
            routes: [
              {
                path: '/contenedores/campos',
                component: ComponentCreator('/contenedores/campos', '6d8'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/contenedores/logs',
                component: ComponentCreator('/contenedores/logs', 'ee8'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/frameworks/astro',
                component: ComponentCreator('/frameworks/astro', 'c8d'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/frameworks/nextjs',
                component: ComponentCreator('/frameworks/nextjs', '1d2'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/frameworks/vanilla',
                component: ComponentCreator('/frameworks/vanilla', 'b2c'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/frameworks/vite',
                component: ComponentCreator('/frameworks/vite', 'ef9'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/plantilla/campos',
                component: ComponentCreator('/plantilla/campos', '263'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/proyectos/facturascripts',
                component: ComponentCreator('/proyectos/facturascripts', 'c5a'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/proyectos/n8n',
                component: ComponentCreator('/proyectos/n8n', '066'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/proyectos/postgres',
                component: ComponentCreator('/proyectos/postgres', '704'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/proyectos/wordpress',
                component: ComponentCreator('/proyectos/wordpress', '63a'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/tutorial-basics/congratulations',
                component: ComponentCreator('/tutorial-basics/congratulations', '855'),
                exact: true
              },
              {
                path: '/tutorial-basics/create-a-blog-post',
                component: ComponentCreator('/tutorial-basics/create-a-blog-post', 'af7'),
                exact: true
              },
              {
                path: '/tutorial-basics/create-a-document',
                component: ComponentCreator('/tutorial-basics/create-a-document', 'bd4'),
                exact: true
              },
              {
                path: '/tutorial-basics/create-a-page',
                component: ComponentCreator('/tutorial-basics/create-a-page', 'aed'),
                exact: true
              },
              {
                path: '/tutorial-basics/deploy-your-site',
                component: ComponentCreator('/tutorial-basics/deploy-your-site', 'f5a'),
                exact: true
              },
              {
                path: '/tutorial-basics/markdown-features',
                component: ComponentCreator('/tutorial-basics/markdown-features', '89e'),
                exact: true
              },
              {
                path: '/tutorial-extras/manage-docs-versions',
                component: ComponentCreator('/tutorial-extras/manage-docs-versions', 'e1f'),
                exact: true
              },
              {
                path: '/tutorial-extras/translate-your-site',
                component: ComponentCreator('/tutorial-extras/translate-your-site', 'dea'),
                exact: true
              },
              {
                path: '/',
                component: ComponentCreator('/', '7da'),
                exact: true,
                sidebar: "docs"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
