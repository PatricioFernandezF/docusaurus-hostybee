export default [
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\hostybee-docs\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\hostybee-docs\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\hostybee-docs\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\Patricio\\Documents\\Codigos Patricio\\hostybee-docs\\src\\css\\custom.css"),
];
